<?php

namespace Gokwik\Api\Errors;

class GatewayError extends Error
{
}