<?php

namespace Gokwik\Api\Errors;

class ServerError extends Error
{
}