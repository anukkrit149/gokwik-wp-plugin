<?php

namespace Gokwik\Api\Errors;

use Exception;

class SignatureVerificationError extends Exception
{
}