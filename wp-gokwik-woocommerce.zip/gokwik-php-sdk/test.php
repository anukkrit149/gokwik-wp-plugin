<?php
/********************
 * Developed by Anukkrit Shanker
 * Time-07:57 PM
 * Date-06-02-2021
 * File-test.php
 * Project-gokwik-php-sdk
 * Copyrights Reserved
 * Created by PhpStorm
 *
 * Working-
 *********************/

include 'Gokwik.php';
use Gokwik\Api\App;
$obj = new App('d32528805bc1bf7d26900007e9eb7f22','435c485ef6adb9c1468a633f487dc509',"Anukkrit");
//$order = array(
//    'order'=>array(
//        "id" => "300681",
//        "status" => "",
//        "total"=> "18.00",
//        "subtotal"=> "18",
//        "total_line_items"=> "1",
//        "total_line_items_quantity"=> "1",
//        "total_tax"=> "0",
//        "total_shipping"=> "0.00",
//        "total_discount"=> "0",
//        "promo_code"=> "aabs",
//        "source"=> "aaaa",
//        "payment_details" => array(
//             "method_id"=> "upi"
//        ),
//        "billing_address" => array(
//           "first_name"=> "Test",
//            "last_name"=> "Shop",
//            "company"=> "Test",
//            "address_1"=> "Test",
//            "address_2"=> "",
//            "city"=> "Delhi",
//            "state"=> "DL",
//            "postcode"=> "110092",
//            "country"=> "IN",
//            "email"=> "v@gokwik.co",
//            "phone"=> "9899764754"
//        ),
//        "shipping_address"=>array(
//            "first_name"=> "",
//            "last_name"=> "",
//            "company"=> "",
//            "address_1"=> "",
//            "address_2"=> "",
//            "city"=> "",
//            "state"=> "",
//            "postcode"=> "",
//            "country"=> ""
//        ),
//        "customer_ip"=> "103.82.80.57",
//        "customer_user_agent"=> "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.16; rv:86.0) Gecko/20100101 Firefox/86.0",
//        "line_items" => array(array(
//            "product_id"=> 15,
//            "variation_id"=> 0,
//            "product"=> array(),
//            "name"=> "Beanie",
//            "sku"=> "woo-beanie",
//            "price"=> 18,
//            "quantity"=> 1,
//            "subtotal"=> "18",
//            "total"=> "18",
//            "tax"=> "0",
//            "taxclass"=> "",
//            "taxstat"=> "taxable",
//            "allmeta"=> [],
//            "somemeta"=> "",
//            "type"=> "line_item",
//            "product_url"=> "https://woo.akash.guru/product/beanie/",
//            "product_thumbnail_url"=> "https://woo.akash.guru/wp-content/uploads/2021/01/beanie-2-150x150.jpg"
//        )),
//        "order_notes"=> "[]"
//    )
//);
//$order = array(
//    "gokwik_oid" => "KWIK4FA7J4XP3892956",
//    "moid" => "300681",
//    "new_status" => "processing"
//);
//$order = order, JSON_PRETTY_PRINT);
//echo $order;
//$res = $obj->order->create(json_encode($order));
//$res = $obj->order->update($order);
//var_dump($res);

$data = array(
    'url' => "woo.akash.guru",
    "status" => "activate",
    "is_active" => 1,
);
$res = $obj->plugin->activate("woo.akash.guru");
var_dump($res);


?>


